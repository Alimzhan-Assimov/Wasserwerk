## To run the API you have to change the password and the user in db.js

``` shell
    const user = "";
    const password = "";
```
## You will also have to create the databse with all the tables and inserts in the Wasserwerk.sql

## How to build

``` shell
    npm i
    npm i express
    npm i mysql2 
    npm run dev
```

## Time worked

29.03 10:10am till 13pm
30.03 12:10am till 14pm